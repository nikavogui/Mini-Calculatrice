﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormCALCULATRICENIKAVOGUIDEV
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.ButtonEGAL = New System.Windows.Forms.Button()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.ButtonADD = New System.Windows.Forms.Button()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.ButtonVIRGULE = New System.Windows.Forms.Button()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.ButtonSOUS = New System.Windows.Forms.Button()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.ButtonZERO = New System.Windows.Forms.Button()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.ButtonMULTI = New System.Windows.Forms.Button()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.ButtonDIVISION = New System.Windows.Forms.Button()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.ButtonEFFACER = New System.Windows.Forms.Button()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.ButtonANNULER = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.ButtonCOPIER = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TextBoxAFFICHAGE = New System.Windows.Forms.TextBox()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(6, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(415, 335)
        Me.Panel1.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Panel20)
        Me.Panel3.Controls.Add(Me.Panel16)
        Me.Panel3.Controls.Add(Me.Panel21)
        Me.Panel3.Controls.Add(Me.Panel12)
        Me.Panel3.Controls.Add(Me.Panel22)
        Me.Panel3.Controls.Add(Me.Panel17)
        Me.Panel3.Controls.Add(Me.Panel8)
        Me.Panel3.Controls.Add(Me.Panel18)
        Me.Panel3.Controls.Add(Me.Panel19)
        Me.Panel3.Controls.Add(Me.Panel13)
        Me.Panel3.Controls.Add(Me.Panel7)
        Me.Panel3.Controls.Add(Me.Panel14)
        Me.Panel3.Controls.Add(Me.Panel15)
        Me.Panel3.Controls.Add(Me.Panel9)
        Me.Panel3.Controls.Add(Me.Panel10)
        Me.Panel3.Controls.Add(Me.Panel6)
        Me.Panel3.Controls.Add(Me.Panel11)
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Controls.Add(Me.Panel5)
        Me.Panel3.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel3.Location = New System.Drawing.Point(12, 90)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(393, 236)
        Me.Panel3.TabIndex = 1
        '
        'Panel20
        '
        Me.Panel20.Controls.Add(Me.ButtonEGAL)
        Me.Panel20.Location = New System.Drawing.Point(293, 190)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(92, 41)
        Me.Panel20.TabIndex = 22
        '
        'ButtonEGAL
        '
        Me.ButtonEGAL.Location = New System.Drawing.Point(3, 1)
        Me.ButtonEGAL.Name = "ButtonEGAL"
        Me.ButtonEGAL.Size = New System.Drawing.Size(86, 37)
        Me.ButtonEGAL.TabIndex = 0
        Me.ButtonEGAL.Text = "="
        Me.ButtonEGAL.UseVisualStyleBackColor = True
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.ButtonADD)
        Me.Panel16.Location = New System.Drawing.Point(292, 146)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(92, 41)
        Me.Panel16.TabIndex = 18
        '
        'ButtonADD
        '
        Me.ButtonADD.Location = New System.Drawing.Point(3, 1)
        Me.ButtonADD.Name = "ButtonADD"
        Me.ButtonADD.Size = New System.Drawing.Size(86, 37)
        Me.ButtonADD.TabIndex = 0
        Me.ButtonADD.Text = "+"
        Me.ButtonADD.UseVisualStyleBackColor = True
        '
        'Panel21
        '
        Me.Panel21.Controls.Add(Me.ButtonVIRGULE)
        Me.Panel21.Location = New System.Drawing.Point(198, 190)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(92, 41)
        Me.Panel21.TabIndex = 21
        '
        'ButtonVIRGULE
        '
        Me.ButtonVIRGULE.Location = New System.Drawing.Point(3, 1)
        Me.ButtonVIRGULE.Name = "ButtonVIRGULE"
        Me.ButtonVIRGULE.Size = New System.Drawing.Size(86, 37)
        Me.ButtonVIRGULE.TabIndex = 0
        Me.ButtonVIRGULE.Text = ","
        Me.ButtonVIRGULE.UseVisualStyleBackColor = True
        '
        'Panel12
        '
        Me.Panel12.Controls.Add(Me.ButtonSOUS)
        Me.Panel12.Location = New System.Drawing.Point(292, 99)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(92, 41)
        Me.Panel12.TabIndex = 14
        '
        'ButtonSOUS
        '
        Me.ButtonSOUS.Location = New System.Drawing.Point(3, 1)
        Me.ButtonSOUS.Name = "ButtonSOUS"
        Me.ButtonSOUS.Size = New System.Drawing.Size(86, 37)
        Me.ButtonSOUS.TabIndex = 0
        Me.ButtonSOUS.Text = "-"
        Me.ButtonSOUS.UseVisualStyleBackColor = True
        '
        'Panel22
        '
        Me.Panel22.Controls.Add(Me.ButtonZERO)
        Me.Panel22.Location = New System.Drawing.Point(100, 189)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(92, 41)
        Me.Panel22.TabIndex = 20
        '
        'ButtonZERO
        '
        Me.ButtonZERO.Location = New System.Drawing.Point(3, 1)
        Me.ButtonZERO.Name = "ButtonZERO"
        Me.ButtonZERO.Size = New System.Drawing.Size(86, 37)
        Me.ButtonZERO.TabIndex = 0
        Me.ButtonZERO.Text = "0"
        Me.ButtonZERO.UseVisualStyleBackColor = True
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.Button3)
        Me.Panel17.Location = New System.Drawing.Point(197, 146)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(92, 41)
        Me.Panel17.TabIndex = 17
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(3, 1)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(86, 37)
        Me.Button3.TabIndex = 0
        Me.Button3.Text = "3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.ButtonMULTI)
        Me.Panel8.Location = New System.Drawing.Point(292, 52)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(92, 41)
        Me.Panel8.TabIndex = 10
        '
        'ButtonMULTI
        '
        Me.ButtonMULTI.Location = New System.Drawing.Point(3, 1)
        Me.ButtonMULTI.Name = "ButtonMULTI"
        Me.ButtonMULTI.Size = New System.Drawing.Size(86, 37)
        Me.ButtonMULTI.TabIndex = 0
        Me.ButtonMULTI.Text = "x"
        Me.ButtonMULTI.UseVisualStyleBackColor = True
        '
        'Panel18
        '
        Me.Panel18.Controls.Add(Me.Button2)
        Me.Panel18.Location = New System.Drawing.Point(99, 145)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(92, 41)
        Me.Panel18.TabIndex = 16
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(3, 1)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(86, 37)
        Me.Button2.TabIndex = 0
        Me.Button2.Text = "2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Panel19
        '
        Me.Panel19.Controls.Add(Me.Button1)
        Me.Panel19.Location = New System.Drawing.Point(4, 144)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(92, 41)
        Me.Panel19.TabIndex = 15
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(3, 1)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(86, 37)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel13
        '
        Me.Panel13.Controls.Add(Me.Button6)
        Me.Panel13.Location = New System.Drawing.Point(197, 99)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(92, 41)
        Me.Panel13.TabIndex = 13
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(3, 1)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(86, 37)
        Me.Button6.TabIndex = 0
        Me.Button6.Text = "6"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.ButtonDIVISION)
        Me.Panel7.Location = New System.Drawing.Point(292, 5)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(92, 41)
        Me.Panel7.TabIndex = 6
        '
        'ButtonDIVISION
        '
        Me.ButtonDIVISION.Location = New System.Drawing.Point(3, 1)
        Me.ButtonDIVISION.Name = "ButtonDIVISION"
        Me.ButtonDIVISION.Size = New System.Drawing.Size(86, 37)
        Me.ButtonDIVISION.TabIndex = 0
        Me.ButtonDIVISION.Text = "/"
        Me.ButtonDIVISION.UseVisualStyleBackColor = True
        '
        'Panel14
        '
        Me.Panel14.Controls.Add(Me.Button5)
        Me.Panel14.Location = New System.Drawing.Point(99, 98)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(92, 41)
        Me.Panel14.TabIndex = 12
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(3, 1)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(86, 37)
        Me.Button5.TabIndex = 0
        Me.Button5.Text = "5"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Panel15
        '
        Me.Panel15.Controls.Add(Me.Button4)
        Me.Panel15.Location = New System.Drawing.Point(4, 97)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(92, 41)
        Me.Panel15.TabIndex = 11
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(3, 1)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(86, 37)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.Button9)
        Me.Panel9.Location = New System.Drawing.Point(197, 52)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(92, 41)
        Me.Panel9.TabIndex = 9
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(3, 1)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(86, 37)
        Me.Button9.TabIndex = 0
        Me.Button9.Text = "9"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.Button8)
        Me.Panel10.Location = New System.Drawing.Point(99, 51)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(92, 41)
        Me.Panel10.TabIndex = 8
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(3, 1)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(86, 37)
        Me.Button8.TabIndex = 0
        Me.Button8.Text = "8"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.ButtonEFFACER)
        Me.Panel6.Location = New System.Drawing.Point(197, 5)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(92, 41)
        Me.Panel6.TabIndex = 5
        '
        'ButtonEFFACER
        '
        Me.ButtonEFFACER.Location = New System.Drawing.Point(3, 1)
        Me.ButtonEFFACER.Name = "ButtonEFFACER"
        Me.ButtonEFFACER.Size = New System.Drawing.Size(86, 37)
        Me.ButtonEFFACER.TabIndex = 0
        Me.ButtonEFFACER.Text = "Effacer"
        Me.ButtonEFFACER.UseVisualStyleBackColor = True
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.Button7)
        Me.Panel11.Location = New System.Drawing.Point(4, 50)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(92, 41)
        Me.Panel11.TabIndex = 7
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(3, 1)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(86, 37)
        Me.Button7.TabIndex = 0
        Me.Button7.Text = "7"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.ButtonANNULER)
        Me.Panel4.Location = New System.Drawing.Point(99, 4)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(92, 41)
        Me.Panel4.TabIndex = 4
        '
        'ButtonANNULER
        '
        Me.ButtonANNULER.Location = New System.Drawing.Point(3, 1)
        Me.ButtonANNULER.Name = "ButtonANNULER"
        Me.ButtonANNULER.Size = New System.Drawing.Size(86, 37)
        Me.ButtonANNULER.TabIndex = 0
        Me.ButtonANNULER.Text = "Annuler"
        Me.ButtonANNULER.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.ButtonCOPIER)
        Me.Panel5.Location = New System.Drawing.Point(4, 3)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(92, 41)
        Me.Panel5.TabIndex = 3
        '
        'ButtonCOPIER
        '
        Me.ButtonCOPIER.Location = New System.Drawing.Point(3, 1)
        Me.ButtonCOPIER.Name = "ButtonCOPIER"
        Me.ButtonCOPIER.Size = New System.Drawing.Size(86, 37)
        Me.ButtonCOPIER.TabIndex = 0
        Me.ButtonCOPIER.Text = "Copier"
        Me.ButtonCOPIER.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.TextBoxAFFICHAGE)
        Me.Panel2.Font = New System.Drawing.Font("Arial Narrow", 35.75!, System.Drawing.FontStyle.Bold)
        Me.Panel2.Location = New System.Drawing.Point(10, 9)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(395, 72)
        Me.Panel2.TabIndex = 0
        '
        'TextBoxAFFICHAGE
        '
        Me.TextBoxAFFICHAGE.Location = New System.Drawing.Point(9, 5)
        Me.TextBoxAFFICHAGE.Name = "TextBoxAFFICHAGE"
        Me.TextBoxAFFICHAGE.Size = New System.Drawing.Size(377, 62)
        Me.TextBoxAFFICHAGE.TabIndex = 0
        Me.TextBoxAFFICHAGE.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'FormCALCULATRICENIKAVOGUIDEV
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(428, 347)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "FormCALCULATRICENIKAVOGUIDEV"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CALCULATRICE NIKAVOGUI DEV"
        Me.Panel1.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel20.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.Panel21.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.Panel22.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel18.ResumeLayout(False)
        Me.Panel19.ResumeLayout(False)
        Me.Panel13.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.Panel14.ResumeLayout(False)
        Me.Panel15.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel20 As Panel
    Friend WithEvents ButtonEGAL As Button
    Friend WithEvents Panel16 As Panel
    Friend WithEvents ButtonADD As Button
    Friend WithEvents Panel21 As Panel
    Friend WithEvents ButtonVIRGULE As Button
    Friend WithEvents Panel12 As Panel
    Friend WithEvents ButtonSOUS As Button
    Friend WithEvents Panel22 As Panel
    Friend WithEvents ButtonZERO As Button
    Friend WithEvents Panel17 As Panel
    Friend WithEvents Button3 As Button
    Friend WithEvents Panel8 As Panel
    Friend WithEvents ButtonMULTI As Button
    Friend WithEvents Panel18 As Panel
    Friend WithEvents Button2 As Button
    Friend WithEvents Panel19 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Button6 As Button
    Friend WithEvents Panel7 As Panel
    Friend WithEvents ButtonDIVISION As Button
    Friend WithEvents Panel14 As Panel
    Friend WithEvents Button5 As Button
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Button4 As Button
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Button9 As Button
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Button8 As Button
    Friend WithEvents Panel6 As Panel
    Friend WithEvents ButtonEFFACER As Button
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Button7 As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents ButtonANNULER As Button
    Friend WithEvents Panel5 As Panel
    Friend WithEvents ButtonCOPIER As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TextBoxAFFICHAGE As TextBox
End Class
