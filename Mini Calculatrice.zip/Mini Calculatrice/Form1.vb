﻿Public Class FormCALCULATRICENIKAVOGUIDEV
    'Declaration des constantes Division par Zero et erreur de Syntaxe
    Const divisionParZero As String = "Erreur"
    Const erreurDeSyntaxe As String = "Erreur de Syntaxe"
    'Declaration d'une variable virgule comme une boolean
    Dim virguleActive As Boolean = False
    'Procedure pour activer les operateurs
    Private Sub ActiveOperationButton(activer As Boolean)
        activer = True
        ButtonMULTI.Enabled = activer
        ButtonDIVISION.Enabled = activer
        ButtonADD.Enabled = activer
        If (Not activer) Then
            virguleActive = False
        End If
    End Sub
    'Procedure pour la verification du button sur lequel on fait un click
    Private Sub Verification_ButtonClick()
        If (TextBoxAFFICHAGE.Text = divisionParZero Or TextBoxAFFICHAGE.Text = erreurDeSyntaxe) Then
            TextBoxAFFICHAGE.Clear()

        End If
        If (operationPrecedent <> Operation.none) Then
            ActiveOperationButton(True)
        End If
    End Sub
    'Declaration d'une variable Enumeration qui va contenir les Operateurs
    Enum Operation
        add
        sous
        mult
        div
        none
    End Enum
    'initialisation des operations precedentes et courantes
    Dim operationPrecedent As Operation = Operation.none
    Dim operationCourante As Operation = Operation.none

    Private Sub ButtonCOPIER_Click(sender As Object, e As EventArgs) Handles ButtonCOPIER.Click
        'Procedure pour copier le texte dans la zone de saisie
        If (String.IsNullOrWhiteSpace(TextBoxAFFICHAGE.Text)) Then
            Return
        End If
        Clipboard.SetText(TextBoxAFFICHAGE.Text)
    End Sub

    Private Sub ButtonANNULER_Click(sender As Object, e As EventArgs) Handles ButtonANNULER.Click
        virguleActive = False
        Verification_ButtonClick()
        operationPrecedent = Operation.none
        TextBoxAFFICHAGE.Clear()
    End Sub
    'Procedure pour effacer caractere par caractere
    Private Sub ButtonEFFACER_Click(sender As Object, e As EventArgs) Handles ButtonEFFACER.Click
        virguleActive = False
        Verification_ButtonClick()
        If (TextBoxAFFICHAGE.Text.Length > 0) Then
            Dim d As Double
            If (Not Double.TryParse(TextBoxAFFICHAGE.Text.Length - 1.ToString(), d)) Then
                operationPrecedent = Operation.none
            End If
            TextBoxAFFICHAGE.Text = TextBoxAFFICHAGE.Text.Remove(TextBoxAFFICHAGE.Text.Length - 1, 1)
        End If
        If (TextBoxAFFICHAGE.Text.Length = 0) Then
            operationPrecedent = Operation.none
        End If
        If (operationPrecedent <> Operation.none) Then
            operationCourante = operationPrecedent
        End If
    End Sub
    'Procedure pour effectuer les calculs avec les differents operateurs
    Private Sub CalculProgramme(operationPrecedent As Operation)
        Try
            If (operationPrecedent = Operation.none) Then
                Return
            End If
            'Declaration d'une variable List de type double
            Dim listNum As List(Of Double)
            Select Case (operationPrecedent)
                'operateur Addition
                Case Operation.add
                    If (operationCourante = Operation.sous) Then
                        operationCourante = Operation.add
                    End If
                    listNum = TextBoxAFFICHAGE.Text.Split("+").Select(Of Double)(AddressOf Double.Parse).ToList()
                    TextBoxAFFICHAGE.Text = (listNum(0) + listNum(1)).ToString()
                    Exit Select
                    'Operateur Soustraction
                Case Operation.sous
                    Dim idx As Integer = TextBoxAFFICHAGE.Text.LastIndexOf("-")
                    If (idx > 0) Then
                        Dim op1 As Double = Convert.ToDouble(TextBoxAFFICHAGE.Text.Substring(0, idx))
                        Dim op2 As Double = Convert.ToDouble(TextBoxAFFICHAGE.Text.Substring(idx + 1))
                        TextBoxAFFICHAGE.Text = (op1 - op2).ToString()
                    End If
                    Exit Select
                    'Operateur Multiplication
                Case Operation.mult
                    If (operationCourante = Operation.sous) Then
                        operationCourante = Operation.mult
                        Return
                    End If
                    listNum = TextBoxAFFICHAGE.Text.Split("x").Select(Of Double)(AddressOf Double.Parse).ToList()
                    TextBoxAFFICHAGE.Text = (listNum(0) * listNum(1)).ToString()
                    Exit Select
                Case Operation.div
                    If (operationCourante = Operation.sous) Then
                        operationCourante = Operation.div
                        Return
                    End If
                    Try
                        listNum = TextBoxAFFICHAGE.Text.Split("/").Select(Of Double)(AddressOf Double.Parse).ToList()
                        If (listNum(1) = 0) Then
                            Throw New DivideByZeroException()
                        End If
                        TextBoxAFFICHAGE.Text = (listNum(0) / listNum(1)).ToString()
                    Catch ex As DivideByZeroException
                        TextBoxAFFICHAGE.Text = divisionParZero
                    End Try
                    Exit Select
                Case Operation.none
                Case Else
                    Exit Select
            End Select
        Catch ex As Exception
            TextBoxAFFICHAGE.Text = erreurDeSyntaxe
        End Try
    End Sub

    Private Sub ButtonDIVISION_Click(sender As Object, e As EventArgs) Handles ButtonDIVISION.Click
        If (TextBoxAFFICHAGE.Text.Length = 0) Then
            Return
        End If
        Verification_ButtonClick()
        operationCourante = Operation.div
        CalculProgramme(operationPrecedent)
        operationPrecedent = operationCourante
        ActiveOperationButton(False)
        TextBoxAFFICHAGE.Text += ButtonDIVISION.Text
    End Sub

    Private Sub ButtonMULTI_Click(sender As Object, e As EventArgs) Handles ButtonMULTI.Click
        If (TextBoxAFFICHAGE.Text.Length = 0) Then
            Return
        End If
        Verification_ButtonClick()
        operationCourante = Operation.mult
        CalculProgramme(operationPrecedent)
        operationPrecedent = operationCourante
        ActiveOperationButton(False)
        TextBoxAFFICHAGE.Text += ButtonMULTI.Text
    End Sub

    Private Sub ButtonSOUS_Click(sender As Object, e As EventArgs) Handles ButtonSOUS.Click
        If (TextBoxAFFICHAGE.Text.Length = 0) Then
            Return
        End If
        Verification_ButtonClick()
        operationCourante = Operation.sous
        CalculProgramme(operationPrecedent)
        operationPrecedent = operationCourante
        ActiveOperationButton(False)
        TextBoxAFFICHAGE.Text += ButtonSOUS.Text
    End Sub

    Private Sub ButtonADD_Click(sender As Object, e As EventArgs) Handles ButtonADD.Click
        If (TextBoxAFFICHAGE.Text.Length = 0) Then
            Return
        End If
        Verification_ButtonClick()
        operationCourante = Operation.add
        CalculProgramme(operationPrecedent)
        operationPrecedent = operationCourante
        ActiveOperationButton(False)
        TextBoxAFFICHAGE.Text += ButtonADD.Text
    End Sub

    Private Sub ButtonEGAL_Click(sender As Object, e As EventArgs) Handles ButtonEGAL.Click
        If (TextBoxAFFICHAGE.Text.Length = 0) Then
            Return
        End If
        If (operationPrecedent <> Operation.none) Then
            CalculProgramme(operationPrecedent)
        End If
        operationPrecedent = Operation.none
    End Sub

    Private Sub ButtonVIRGULE_Click(sender As Object, e As EventArgs) Handles ButtonVIRGULE.Click
        If (virguleActive) Then
            Return
        End If
        If (TextBoxAFFICHAGE.Text = erreurDeSyntaxe Or TextBoxAFFICHAGE.Text = divisionParZero) Then
            TextBoxAFFICHAGE.Text = String.Empty
        End If
        ActiveOperationButton(True)
        Verification_ButtonClick()
        TextBoxAFFICHAGE.Text += ButtonVIRGULE.Text
        virguleActive = True
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        TextBoxAFFICHAGE.Text += Button7.Text
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        TextBoxAFFICHAGE.Text += Button8.Text
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        TextBoxAFFICHAGE.Text += Button9.Text
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        TextBoxAFFICHAGE.Text += Button4.Text
    End Sub


    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        TextBoxAFFICHAGE.Text += Button6.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBoxAFFICHAGE.Text += Button1.Text
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBoxAFFICHAGE.Text += Button2.Text
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBoxAFFICHAGE.Text += Button3.Text
    End Sub

    Private Sub ButtonZERO_Click(sender As Object, e As EventArgs) Handles ButtonZERO.Click
        TextBoxAFFICHAGE.Text += ButtonZERO.Text
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        TextBoxAFFICHAGE.Text += Button5.Text
    End Sub
End Class
